# PRODIGY_AD_04
Develop a Tic Tac Toe game app where two players can take turns to place their symbols (X or 0) on a 3x3 grid. The objective is to form a horizontal, vertical, or diagonal line of three of their symbols to win the game. The app should also include a reset option to start a new game.
![Screenshot 2024-02-29 204710](https://github.com/siddhithorat/PRODIGY_AD_04/assets/101985797/e50c3c23-0e04-457a-afb0-7fba2b8debf0)
![Screenshot 2024-02-29 204807](https://github.com/siddhithorat/PRODIGY_AD_04/assets/101985797/c18af021-2374-42a7-934d-f9a64707f4bd)
